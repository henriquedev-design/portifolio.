# GestorPro

Projeto demonstrativo de gestão empresarial feito com Python, Flask, SQLite, HTML e CSS.

## Executar no VS Code
1. Instale Python 3.
2. Abra esta pasta no VS Code.
3. No terminal, execute: `python -m venv .venv`
4. Ative o ambiente virtual.
   - Windows: `.venv\\Scripts\\activate`
   - macOS/Linux: `source .venv/bin/activate`
5. Instale as dependências: `pip install -r requirements.txt`
6. Execute: `python app.py`
7. Abra `http://127.0.0.1:5000` no navegador.

A página `preview.html` é uma demonstração visual estática. O sistema Flask é executado localmente.
Este projeto é educativo e não está preparado para uso comercial em produção.
